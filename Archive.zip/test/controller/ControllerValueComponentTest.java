package controller;

/**
 * Tests for value-component command for controller.
 */
public class ControllerValueComponentTest {
}
