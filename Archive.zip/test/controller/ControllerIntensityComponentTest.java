package controller;

/**
 * Tests for intensity-component command for controller.
 */
public class ControllerIntensityComponentTest {
}
