package controller;

/**
 * Tests for luma-component command for controller.
 */
public class ControllerLumaComponentTest {
}
