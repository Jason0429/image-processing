package controller;

/**
 * Tests brighten command for controller.
 */
public class ControllerBrightenTest {
}
