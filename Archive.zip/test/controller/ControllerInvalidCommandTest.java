package controller;

/**
 * Tests invalid commands for controller.
 */
public class ControllerInvalidCommandTest {
}
