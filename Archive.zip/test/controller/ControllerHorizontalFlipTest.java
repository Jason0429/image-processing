package controller;

/**
 * Tests horizontal-component for controller.
 */
public class ControllerHorizontalFlipTest {
}
