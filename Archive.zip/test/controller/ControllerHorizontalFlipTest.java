package controller;

/**
 * Tests for horizontal-flip command
 */
public class ControllerHorizontalFlipTest {
}
