package controller;

/**
 * Tests for green-component command in controller.
 */
public class ControllerGreenComponentTest {
}
