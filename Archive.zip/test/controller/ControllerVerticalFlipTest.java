package controller;

/**
 * Tests vertical-flip command for controller.
 */
public class ControllerVerticalFlipTest {
}
