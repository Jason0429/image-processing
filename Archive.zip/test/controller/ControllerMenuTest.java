package controller;

/**
 * Tests menu command in controller.
 */
public class ControllerMenuTest {
}
