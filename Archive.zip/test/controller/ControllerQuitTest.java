package controller;

/**
 * Tests quit command for controller.
 */
public class ControllerQuitTest {
}
