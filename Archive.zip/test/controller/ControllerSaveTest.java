package controller;

/**
 * Tests for save command in controller.
 */
public class ControllerSaveTest {
}
