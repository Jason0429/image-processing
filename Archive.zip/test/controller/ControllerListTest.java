package controller;

/**
 * Tests for list command in controller.
 */
public class ControllerListTest {
}
