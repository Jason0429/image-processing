package controller;

/**
 * Tests for red-component command in controller.
 */
public class ControllerRedComponentTest {
}
