Options:

`menu` (loads this menu)

`list` (lists all loaded image names)

`load` [`image-path`] [`image-name`]

`save` [`image-path`] [`image-name`]

`red-component` [`image-name`] [`dest-image-name`]

`green-component` [`image-name`] [`dest-image-name`]

`blue-component` [`image-name`] [`dest-image-name`]

`value-component` [`image-name`] [`dest-image-name`]

`luma-component` [`image-name`] [`dest-image-name`]

`intensity-component` [`image-name`] [`dest-image-name`]

`horizontal-flip` [`image-name`] [`dest-image-name`]

`vertical-flip` [`image-name`] [`dest-image-name`]

`brighten` [`image-name`] [`dest-image-name`] [`increment`]

`gaussian-blur` [`image-name`] [`dest-image-name`]

`sharpen` [`image-name`] [`dest-image-name`]

`quit`/`q` (quit the program)